# NT531 – Lab 4

## Chạy nhanh
Cần Python có bindings NS-3 >= 3.43 và matplotlib.

```bash
python run_all.py
```

Hoặc từng kịch bản:
```bash
python scenario4a_corrected.py
python scenario4b.py
python scenario4c.py --queue=DropTail
python scenario4c.py --queue=FQ
python scenario4c.py --queue=SFQ
python scenario4c.py --queue=RED
python scenario4d.py --tcp=Reno
python scenario4d.py --tcp=NewReno
```

Giữ nguyên scenario4a.py gốc để đối chiếu. Kết quả baseline dùng scenario4a_corrected.py:
gỡ root qdisc SAU khi gán địa chỉ vì Ipv4AddressHelper có thể cài qdisc mặc định khi Assign.
4a/4b/4d chỉ dùng device DropTail 10p tại bottleneck. 4c cài qdisc theo lựa chọn trên cả hai chiều d45.
Các qdisc dùng MaxSize mặc định của NS-3; device queue vẫn 10p. RED khai báo đúng LinkBandwidth/LinkDelay.
Ứng dụng nguồn dừng như đề, sink dừng 5.5s. Simulator dừng 16s để FlowMonitor có đủ timeout mặc định 10s đánh dấu lostPackets; không phát thêm tải ứng dụng trong thời gian chờ.
FQ = FqCoDel; SFQ = FqPie (xấp xỉ, không phải SFQ thuần).
Reno = TcpLinuxReno (có fast recovery, không phải Tahoe); NewReno = TcpNewReno.

Bảng báo cáo chỉ lấy 4 luồng dữ liệu hướng tới 10.1.5.2, không cộng các flow ACK TCP chiều ngược.
Throughput theo analyzer dùng rxBytes IP / (lastRx - firstTx), có header và khác goodput ứng dụng.
Dropped là tổng packetsDropped mà FlowMonitor ghi nhận; không đảm bảo đếm đủ mọi drop tại device/qdisc trên mọi bản NS-3.
Lost bao gồm packet drop đã biết; không cộng Dropped + Lost thành tổng mất.

NetAnim: mở results/*-netanim.xml bằng NetAnim, bấm Play rồi chụp ảnh khi có gói. Ảnh topology vẽ lại không thay thế ảnh chụp NetAnim.
Điền họ tên, MSSV và đổi tên ZIP theo yêu cầu trước khi nộp.

Môi trường thực hiện dùng wheel ns3==3.44.post0, cppyy==3.5.0 với GCC.
Đã sửa loader cục bộ để chỉ tìm thư viện có basename bắt đầu libns3. (loader gốc nhận nhầm thư viện phụ trong thư mục ns3 khi dùng pip --target).
Console có cảnh báo cppyy/API và cling static initializer, nhưng tiến trình hoàn tất exit 0 và sinh đủ XML/trace/biểu đồ; xem các console log đi kèm. Các số liệu là kết quả của môi trường này; nên chạy lại trên bản NS-3 được trường cung cấp nếu cần đối chiếu.
