#!/usr/bin/env python3
"""Run all 8 simulations and the supplied analyzer. Outputs: results/."""
import subprocess, sys
from pathlib import Path
BASE = Path(__file__).resolve().parent
OUT = BASE / 'results'
OUT.mkdir(exist_ok=True)
cases=[('scenario4a_corrected.py', [], 'scenario4a'),('scenario4b.py', [], 'scenario4b')]
cases += [('scenario4c.py',['--queue='+q],'scenario4c-'+q) for q in ['DropTail','FQ','SFQ','RED']]
cases += [('scenario4d.py',['--tcp='+q],'scenario4d-'+p) for q,p in [('Reno','TCP'),('NewReno','TCPReno')]]
for script,args,prefix in cases:
    print('RUN',prefix,flush=True)
    with (OUT/(prefix+'-console.txt')).open('w') as log:
        subprocess.run([sys.executable,str(BASE/script),*args],cwd=OUT,stdout=log,stderr=subprocess.STDOUT,check=True)
    with (OUT/(prefix+'-analysis.txt')).open('w') as log:
        subprocess.run([sys.executable,str(BASE/'analyze_trace.py'),'--flowmon',prefix+'-flowmon.xml','--plot',prefix+'-throughput.png','--timeseries',prefix+'.tr','--timeseries-out',prefix+'-timeseries.png','--delay-cdf',prefix+'-flowmon.xml','--delay-cdf-out',prefix+'-delay-cdf.png'],cwd=OUT,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Done:',OUT)
