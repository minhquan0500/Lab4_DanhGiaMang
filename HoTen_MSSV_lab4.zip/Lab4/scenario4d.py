#!/usr/bin/env python3
"""
NT531 — Lab 4 Scenario 4a (NS-3 port of scenario4a.tcl)

Topology (6 nodes):
                        n0 ──10Mb/20ms ─┐
                        n1 ──10Mb/20ms ─┤
                                        ├── n4 ──5Mb/20ms── n5
                        n2 ──10Mb/20ms ─┤
                        n3 ──100Mb/20ms─┘

All links use DropTail queues. Bottleneck queue (n4→n5) limited to 10 packets.

Flows (max packet payload = 1000 B):
    TCP 1 (BulkSend / FTP)   : n0 → n5,  start 0.1 s, stop 5.0 s
    TCP 2 (BulkSend / FTP)   : n1 → n5,  start 1.0 s, stop 4.5 s
    UDP 1 (OnOff CBR 1 Mbps) : n2 → n5,  start 1.0 s, stop 5.0 s
    UDP 2 (OnOff CBR 1 Mbps) : n3 → n5,  start 0.2 s, stop 5.0 s

Run (place this file in ns-3's scratch/ folder, or pass full path):
    ./ns3 run "scratch/scenario4a"

Outputs (written to the current ns-3 working dir):
    scenario4a.tr            — ASCII trace (all P2P devices)
    scenario4a-0-0.pcap ...  — per-device pcap
    scenario4a-flowmon.xml   — FlowMonitor statistics
    scenario4a-netanim.xml   — NetAnim animation input
"""

SCENARIO = "4d"
PREFIX = "scenario4d"
import argparse
from ns import ns


def build():
    parser = argparse.ArgumentParser()
    parser.add_argument("--queue", choices=["DropTail", "FQ", "SFQ", "RED"], default="DropTail")
    parser.add_argument("--tcp", choices=["Reno", "NewReno"], default="NewReno")
    args = parser.parse_args()
    prefix = PREFIX
    queue = args.queue if SCENARIO == "4c" else "DropTail"
    tcp = args.tcp if SCENARIO == "4d" else "NewReno"
    if SCENARIO == "4c": prefix += "-" + queue
    if SCENARIO == "4d": prefix += "-" + {"Reno": "TCP", "NewReno": "TCPReno"}[tcp]
    # ── Global defaults ──────────────────────────────────────────────
    # NS-2 "tcp packet size = 1000" → SegmentSize = 1000.
    ns.Config.SetDefault("ns3::TcpSocket::SegmentSize", ns.UintegerValue(1000))
    # Default congestion control: TcpNewReno (mirrors NS-2 "Agent/TCP").
    ns.Config.SetDefault(
        "ns3::TcpL4Protocol::SocketType",
        ns.TypeIdValue(ns.TypeId.LookupByName("ns3::TcpLinuxReno" if tcp == "Reno" else "ns3::TcpNewReno")),
    )

    # ── Nodes ────────────────────────────────────────────────────────
    nodes = ns.NodeContainer()
    nodes.Create(6)
    n0, n1, n2, n3, n4, n5 = (nodes.Get(i) for i in range(6))

    # ── Links ────────────────────────────────────────────────────────
    # Three 10 Mbps / 20 ms access links (n0,n1,n2 → n4)
    access10 = ns.PointToPointHelper()
    access10.SetDeviceAttribute("DataRate", ns.StringValue("10Mbps"))
    access10.SetChannelAttribute("Delay", ns.StringValue("20ms"))

    # One 100 Mbps / 20 ms access link (n3 → n4)
    access100 = ns.PointToPointHelper()
    access100.SetDeviceAttribute("DataRate", ns.StringValue("100Mbps"))
    access100.SetChannelAttribute("Delay", ns.StringValue("20ms"))

    # Bottleneck n4 → n5: 5 Mbps / 20 ms, DropTail (10 packets)
    bottleneck = ns.PointToPointHelper()
    bottleneck.SetDeviceAttribute("DataRate", ns.StringValue("50Mbps" if SCENARIO == "4b" else "5Mbps"))
    bottleneck.SetChannelAttribute("Delay", ns.StringValue("10ms" if SCENARIO == "4b" else "20ms"))
    bottleneck.SetQueue(
        "ns3::DropTailQueue",
        "MaxSize", ns.QueueSizeValue(ns.QueueSize("10p")),
    )

    d04 = access10.Install(n0, n4)
    d14 = access10.Install(n1, n4)
    d24 = access10.Install(n2, n4)
    d34 = access100.Install(n3, n4)
    d45 = bottleneck.Install(n4, n5)

    # ── Internet stack + addresses ───────────────────────────────────
    internet = ns.InternetStackHelper()
    internet.Install(nodes)

    addr = ns.Ipv4AddressHelper()
    addr.SetBase(ns.Ipv4Address("10.1.1.0"), ns.Ipv4Mask("255.255.255.0"))
    i04 = addr.Assign(d04)
    addr.SetBase(ns.Ipv4Address("10.1.2.0"), ns.Ipv4Mask("255.255.255.0"))
    i14 = addr.Assign(d14)
    addr.SetBase(ns.Ipv4Address("10.1.3.0"), ns.Ipv4Mask("255.255.255.0"))
    i24 = addr.Assign(d24)
    addr.SetBase(ns.Ipv4Address("10.1.4.0"), ns.Ipv4Mask("255.255.255.0"))
    i34 = addr.Assign(d34)
    addr.SetBase(ns.Ipv4Address("10.1.5.0"), ns.Ipv4Mask("255.255.255.0"))
    i45 = addr.Assign(d45)

    clear = ns.TrafficControlHelper()
    clear.Uninstall(d45)
    if queue != "DropTail":
        tch = ns.TrafficControlHelper()
        qtype = {"FQ": "ns3::FqCoDelQueueDisc", "SFQ": "ns3::FqPieQueueDisc", "RED": "ns3::RedQueueDisc"}[queue]
        if queue == "RED":
            tch.SetRootQueueDisc(qtype, "LinkBandwidth", ns.DataRateValue(ns.DataRate("5Mbps")), "LinkDelay", ns.TimeValue(ns.MilliSeconds(20)))
        else:
            tch.SetRootQueueDisc(qtype)
        tch.Install(d45)

    ns.Ipv4GlobalRoutingHelper.PopulateRoutingTables()

    # n5's interface on the n4-n5 link is index 1 of i45
    n5_addr = i45.GetAddress(1)

    # ── TCP 1: BulkSend (FTP) from n0 to n5 ──────────────────────────
    tcp1_port = 21
    tcp1_sink = ns.PacketSinkHelper(
        "ns3::TcpSocketFactory",
        ns.InetSocketAddress(ns.Ipv4Address.GetAny(), tcp1_port).ConvertTo(),
    )
    tcp1_sink_app = tcp1_sink.Install(n5)
    tcp1_sink_app.Start(ns.Seconds(0.0))
    tcp1_sink_app.Stop(ns.Seconds(5.5))

    ftp1 = ns.BulkSendHelper(
        "ns3::TcpSocketFactory",
        ns.InetSocketAddress(n5_addr, tcp1_port).ConvertTo(),
    )
    ftp1.SetAttribute("MaxBytes", ns.UintegerValue(0))
    ftp1.SetAttribute("SendSize", ns.UintegerValue(1000))
    ftp1_app = ftp1.Install(n0)
    ftp1_app.Start(ns.Seconds(0.1))
    ftp1_app.Stop(ns.Seconds(5.0))

    # ── TCP 2: BulkSend (FTP) from n1 to n5 ──────────────────────────
    tcp2_port = 22
    tcp2_sink = ns.PacketSinkHelper(
        "ns3::TcpSocketFactory",
        ns.InetSocketAddress(ns.Ipv4Address.GetAny(), tcp2_port).ConvertTo(),
    )
    tcp2_sink_app = tcp2_sink.Install(n5)
    tcp2_sink_app.Start(ns.Seconds(0.0))
    tcp2_sink_app.Stop(ns.Seconds(5.5))

    ftp2 = ns.BulkSendHelper(
        "ns3::TcpSocketFactory",
        ns.InetSocketAddress(n5_addr, tcp2_port).ConvertTo(),
    )
    ftp2.SetAttribute("MaxBytes", ns.UintegerValue(0))
    ftp2.SetAttribute("SendSize", ns.UintegerValue(1000))
    ftp2_app = ftp2.Install(n1)
    ftp2_app.Start(ns.Seconds(1.0))
    ftp2_app.Stop(ns.Seconds(4.5))

    # ── UDP 1: OnOff (CBR) from n2 to n5 ─────────────────────────────
    udp1_port = 9
    udp1_sink = ns.PacketSinkHelper(
        "ns3::UdpSocketFactory",
        ns.InetSocketAddress(ns.Ipv4Address.GetAny(), udp1_port).ConvertTo(),
    )
    udp1_sink_app = udp1_sink.Install(n5)
    udp1_sink_app.Start(ns.Seconds(0.0))
    udp1_sink_app.Stop(ns.Seconds(5.5))

    cbr1 = ns.OnOffHelper(
        "ns3::UdpSocketFactory",
        ns.InetSocketAddress(n5_addr, udp1_port).ConvertTo(),
    )
    cbr1.SetAttribute("DataRate", ns.DataRateValue(ns.DataRate("1Mbps")))
    cbr1.SetAttribute("PacketSize", ns.UintegerValue(1000))
    cbr1.SetAttribute("OnTime",
        ns.StringValue("ns3::ConstantRandomVariable[Constant=1]"))
    cbr1.SetAttribute("OffTime",
        ns.StringValue("ns3::ConstantRandomVariable[Constant=0]"))
    cbr1_app = cbr1.Install(n2)
    cbr1_app.Start(ns.Seconds(1.0))
    cbr1_app.Stop(ns.Seconds(5.0))

    # ── UDP 2: OnOff (CBR) from n3 to n5 ─────────────────────────────
    udp2_port = 10
    udp2_sink = ns.PacketSinkHelper(
        "ns3::UdpSocketFactory",
        ns.InetSocketAddress(ns.Ipv4Address.GetAny(), udp2_port).ConvertTo(),
    )
    udp2_sink_app = udp2_sink.Install(n5)
    udp2_sink_app.Start(ns.Seconds(0.0))
    udp2_sink_app.Stop(ns.Seconds(5.5))

    cbr2 = ns.OnOffHelper(
        "ns3::UdpSocketFactory",
        ns.InetSocketAddress(n5_addr, udp2_port).ConvertTo(),
    )
    cbr2.SetAttribute("DataRate", ns.DataRateValue(ns.DataRate("1Mbps")))
    cbr2.SetAttribute("PacketSize", ns.UintegerValue(1000))
    cbr2.SetAttribute("OnTime",
        ns.StringValue("ns3::ConstantRandomVariable[Constant=1]"))
    cbr2.SetAttribute("OffTime",
        ns.StringValue("ns3::ConstantRandomVariable[Constant=0]"))
    cbr2_app = cbr2.Install(n3)
    cbr2_app.Start(ns.Seconds(0.2))
    cbr2_app.Stop(ns.Seconds(5.0))

    # ── Tracing: ASCII + PCAP ────────────────────────────────────────
    # EnableAsciiAll/EnablePcapAll iterate over ALL P2P devices, so a single
    # call on one helper suffices (calling on every helper duplicates events).
    ascii_helper = ns.AsciiTraceHelper()
    tr_stream = ascii_helper.CreateFileStream(prefix + ".tr")
    access10.EnableAsciiAll(tr_stream)
    access10.EnablePcapAll(prefix)

    # ── FlowMonitor ──────────────────────────────────────────────────
    flowmon_helper = ns.FlowMonitorHelper()
    monitor = flowmon_helper.InstallAll()

    # ── Mobility / node layout (matches NS-2 NAM picture) ────────────
    #
    #     n0 (20,10)
    #     n1 (20,35) ──┐
    #                  ├── n4 (50,47) ── n5 (80,47)
    #     n2 (20,60) ──┘
    #     n3 (20,85)
    mobility = ns.MobilityHelper()
    positions = ns.CreateObject[ns.ListPositionAllocator]()
    positions.Add(ns.Vector(20.0, 10.0, 0.0))
    positions.Add(ns.Vector(20.0, 35.0, 0.0))
    positions.Add(ns.Vector(20.0, 60.0, 0.0))
    positions.Add(ns.Vector(20.0, 85.0, 0.0))
    positions.Add(ns.Vector(50.0, 47.0, 0.0))
    positions.Add(ns.Vector(80.0, 47.0, 0.0))
    mobility.SetPositionAllocator(positions)
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel")
    mobility.Install(nodes)

    # ── NetAnim ──────────────────────────────────────────────────────
    anim = ns.AnimationInterface(prefix + "-netanim.xml")

    # ── Run ──────────────────────────────────────────────────────────
    ns.Simulator.Stop(ns.Seconds(16.0))
    ns.Simulator.Run()

    monitor.CheckForLostPackets()
    monitor.SerializeToXmlFile(prefix + "-flowmon.xml", True, True)

    ns.Simulator.Destroy()
    print(f"[{prefix}] Done. Files:")
    print(f"  {prefix}.tr, {prefix}-*.pcap, {prefix}-flowmon.xml, {prefix}-netanim.xml")


if __name__ == "__main__":
    build()
