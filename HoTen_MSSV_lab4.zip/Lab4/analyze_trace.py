#!/usr/bin/env python3
"""
NT531 — Lab 4 trace analysis (same helper as Lab 3).

Usage:
    # Per-flow summary table (Sent/Recv/Dropped/Lost/Success/Delay)
    python3 analyze_trace.py --flowmon scenario4a-flowmon.xml

    # Bar chart of average throughput per flow
    python3 analyze_trace.py --flowmon scenario4a-flowmon.xml \\
        --plot scenario4a-throughput.png

    # Throughput vs time (parses the NS-3 .tr ASCII trace)
    python3 analyze_trace.py --timeseries scenario4a.tr \\
        --timeseries-out scenario4a-timeseries.png

    # End-to-end delay CDF per flow (parses FlowMonitor delayHistogram)
    python3 analyze_trace.py --delay-cdf scenario4a-flowmon.xml \\
        --delay-cdf-out scenario4a-delay-cdf.png
"""

import argparse
import re
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict


# ─────────────────────────────────────────────────────────────────────
# FlowMonitor analysis  →  Vietnamese-labelled summary table
# ─────────────────────────────────────────────────────────────────────

def parse_flowmon(xml_path):
    """Return list of dicts (one per flow) with the stats we report."""
    tree = ET.parse(xml_path)
    root = tree.getroot()

    # FlowMonitor groups: <FlowStats>…</FlowStats> + <Ipv4FlowClassifier>…
    stats_el = root.find("FlowStats")
    class_el = root.find("Ipv4FlowClassifier")
    if stats_el is None or class_el is None:
        sys.exit(f"ERR: {xml_path} is not a FlowMonitor XML output.")

    classifier = {}
    for flow in class_el.findall("Flow"):
        classifier[flow.get("flowId")] = flow.attrib

    results = []
    for flow in stats_el.findall("Flow"):
        fid = flow.get("flowId")
        tx = int(flow.get("txPackets"))
        rx = int(flow.get("rxPackets"))
        lost = int(flow.get("lostPackets"))

        # dropped packets = sum over <packetsDropped reasonCode=…>
        dropped = sum(int(d.get("number"))
                      for d in flow.findall("packetsDropped"))

        # Delays are stored with a "+…ns" suffix
        def ns_to_s(v):
            return float(re.sub(r"[^\d.eE+-]", "", v)) / 1e9
        delay_sum_s = ns_to_s(flow.get("delaySum", "+0.0ns"))
        tx_bytes = int(flow.get("txBytes"))
        rx_bytes = int(flow.get("rxBytes"))
        time_first_tx_s = ns_to_s(flow.get("timeFirstTxPacket", "+0.0ns"))
        time_last_rx_s = ns_to_s(flow.get("timeLastRxPacket", "+0.0ns"))

        mean_delay = (delay_sum_s / rx) if rx > 0 else 0.0
        duration = max(time_last_rx_s - time_first_tx_s, 1e-9)
        throughput_bps = (rx_bytes * 8) / duration
        success_rate = (rx / tx) if tx > 0 else 0.0

        info = classifier.get(fid, {})
        proto_num = info.get("protocol", "0")
        proto = {"6": "TCP", "17": "UDP"}.get(proto_num, f"proto={proto_num}")

        results.append({
            "flowId": fid,
            "proto": proto,
            "src": f"{info.get('sourceAddress','?')}:{info.get('sourcePort','?')}",
            "dst": f"{info.get('destinationAddress','?')}:{info.get('destinationPort','?')}",
            "tx": tx,
            "rx": rx,
            "dropped": dropped,
            "lost": lost,
            "success_rate": success_rate,
            "mean_delay_s": mean_delay,
            "throughput_bps": throughput_bps,
            "tx_bytes": tx_bytes,
            "rx_bytes": rx_bytes,
            "duration": duration,
        })
    return results


def print_table(flows):
    """Print the 6-column table required by the lab handout."""
    print()
    print("═" * 92)
    print(f" {'Flow':<22} {'Sent':>8} {'Recv':>8} {'Dropped':>8} "
          f"{'Lost':>6} {'Success':>9} {'Delay':>10}")
    print("═" * 92)
    for f in flows:
        label = f"{f['flowId']} {f['proto']} {f['src']}→{f['dst']}"
        print(f" {label[:22]:<22} {f['tx']:>8} {f['rx']:>8} "
              f"{f['dropped']:>8} {f['lost']:>6} "
              f"{f['success_rate']*100:>8.2f}% {f['mean_delay_s']*1000:>8.2f} ms")
    print("═" * 92)
    print()
    print("Mapping to lab table columns (bảng trong đề bài):")
    print("  Số gói tin gởi đi       = Sent")
    print("  Số gói tin nhận được    = Recv")
    print("  Số gói tin bị rơi       = Dropped   (queue-drop events)")
    print("  Số gói tin bị mất       = Lost      (FlowMonitor lostPackets)")
    print("  Tỉ lệ truyền thành công = Success")
    print("  Độ trễ trung bình       = Delay")


# ─────────────────────────────────────────────────────────────────────
# Throughput plot (replaces tracegraph's throughput graph)
# ─────────────────────────────────────────────────────────────────────

def plot_throughput(flows, out_path):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        sys.exit("matplotlib is required for --plot (pip install matplotlib)")

    labels = [f"Flow {f['flowId']}\n{f['proto']}" for f in flows]
    values = [f["throughput_bps"] / 1e6 for f in flows]  # Mbps

    fig, ax = plt.subplots(figsize=(7, 4))
    bars = ax.bar(labels, values, color=["#1f77b4", "#d62728", "#2ca02c",
                                          "#9467bd", "#ff7f0e"][: len(flows)])
    ax.set_ylabel("Throughput (Mbps)")
    ax.set_title("Per-flow throughput (FlowMonitor)")
    for bar, v in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, v,
                f"{v:.3f}", ha="center", va="bottom", fontsize=9)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    print(f"Throughput plot saved: {out_path}")


# ─────────────────────────────────────────────────────────────────────
# Throughput time-series from NS-3 ASCII trace
# ─────────────────────────────────────────────────────────────────────
#
# An `r` (receive) event fires on every NIC that sees a frame, so a
# packet traversing n0→n2→n3 produces two `r` events (at n2 and n3).
# To count end-to-end delivery only once, we first learn which IPs live
# on each node (from `+` enqueue events: the src_ip of an enqueue is
# always local to the node doing the enqueue) and then only count `r`
# events whose dst_ip belongs to the receiving node.

TR_EVENT = re.compile(
    r"^(?P<event>[+\-rd])\s+(?P<time>[\d.]+)\s+/NodeList/(?P<node>\d+)/"
)
TR_IPV4 = re.compile(
    r"ns3::Ipv4Header .*?protocol\s+(?P<proto>\d+).*?length:\s*"
    r"(?P<len>\d+)\s+(?P<src>\d+\.\d+\.\d+\.\d+)\s*>\s*"
    r"(?P<dst>\d+\.\d+\.\d+\.\d+)"
)
TR_TCP = re.compile(r"ns3::TcpHeader \((?P<sport>\d+)\s*>\s*(?P<dport>\d+)")
TR_UDP = re.compile(r"ns3::UdpHeader \([^)]*?(?P<sport>\d+)\s*>\s*(?P<dport>\d+)")


def _iter_tr(tr_path):
    with open(tr_path) as fh:
        for line in fh:
            m = TR_EVENT.match(line)
            if not m:
                continue
            ip = TR_IPV4.search(line)
            if not ip:
                continue
            tcp = TR_TCP.search(line)
            udp = TR_UDP.search(line)
            if tcp:
                sport, dport = tcp.group("sport"), tcp.group("dport")
            elif udp:
                sport, dport = udp.group("sport"), udp.group("dport")
            else:
                sport = dport = "0"
            yield {
                "event": m.group("event"),
                "time": float(m.group("time")),
                "node": int(m.group("node")),
                "proto": int(ip.group("proto")),
                "size": int(ip.group("len")),
                "src": ip.group("src"),
                "dst": ip.group("dst"),
                "sport": sport,
                "dport": dport,
            }


def _learn_node_ips(tr_path):
    """node_id → set of local IPs.

    For a given flow 5-tuple, the originator is the node that enqueues
    but never receives (it creates the packet), and the destination is
    the node that receives but never enqueues (it consumes the packet).
    Forwarders do both, so they are excluded from both sets.
    """
    enq_nodes = defaultdict(set)
    recv_nodes = defaultdict(set)
    for e in _iter_tr(tr_path):
        key = (e["src"], e["sport"], e["dst"], e["dport"], e["proto"])
        if e["event"] == "+":
            enq_nodes[key].add(e["node"])
        elif e["event"] == "r":
            recv_nodes[key].add(e["node"])

    node_ips = defaultdict(set)
    for key in enq_nodes.keys() | recv_nodes.keys():
        src, _sport, dst, _dport, _proto = key
        for n in enq_nodes[key] - recv_nodes[key]:
            node_ips[n].add(src)
        for n in recv_nodes[key] - enq_nodes[key]:
            node_ips[n].add(dst)
    return node_ips


def timeseries_plot(tr_path, out_path, bin_ms=100):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        sys.exit("matplotlib is required for --timeseries (pip install matplotlib)")

    node_ips = _learn_node_ips(tr_path)
    proto_name = {6: "TCP", 17: "UDP"}

    bin_s = bin_ms / 1000.0
    per_flow_bytes = defaultdict(lambda: defaultdict(int))

    for e in _iter_tr(tr_path):
        if e["event"] != "r":
            continue
        if e["dst"] not in node_ips[e["node"]]:
            continue  # forwarded hop, not final delivery
        key = (e["proto"], e["src"], e["sport"], e["dst"], e["dport"])
        bucket = int(e["time"] / bin_s)
        per_flow_bytes[key][bucket] += e["size"]

    if not per_flow_bytes:
        sys.exit("No end-to-end receives found in trace — wrong file?")

    fig, ax = plt.subplots(figsize=(9, 5))
    colors = ["#1f77b4", "#d62728", "#2ca02c", "#9467bd", "#ff7f0e", "#17becf"]
    for i, (key, buckets) in enumerate(sorted(per_flow_bytes.items())):
        proto, src, sport, dst, dport = key
        max_bucket = max(buckets)
        xs = [b * bin_s + bin_s / 2 for b in range(max_bucket + 1)]
        ys = [buckets.get(b, 0) * 8 / bin_s / 1e6 for b in range(max_bucket + 1)]
        label = f"{proto_name.get(proto, proto)} {src}:{sport}→{dst}:{dport}"
        ax.plot(xs, ys, label=label, color=colors[i % len(colors)], linewidth=1.5)

    ax.set_xlabel("Time (s)")
    ax.set_ylabel(f"Throughput (Mbps, {bin_ms} ms bins)")
    ax.set_title("Per-flow throughput vs time")
    ax.grid(True, alpha=0.3)
    ax.legend(loc="best", fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    print(f"Time-series plot saved: {out_path}")


# ─────────────────────────────────────────────────────────────────────
# Delay CDF from FlowMonitor delayHistogram
# ─────────────────────────────────────────────────────────────────────

def delay_cdf_plot(flowmon_xml, out_path):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        sys.exit("matplotlib is required for --delay-cdf (pip install matplotlib)")

    tree = ET.parse(flowmon_xml)
    root = tree.getroot()
    stats_el = root.find("FlowStats")
    class_el = root.find("Ipv4FlowClassifier")
    if stats_el is None or class_el is None:
        sys.exit(f"ERR: {flowmon_xml} is not a FlowMonitor XML output.")

    classifier = {f.get("flowId"): f.attrib for f in class_el.findall("Flow")}
    proto_name = {"6": "TCP", "17": "UDP"}

    fig, ax = plt.subplots(figsize=(9, 5))
    colors = ["#1f77b4", "#d62728", "#2ca02c", "#9467bd", "#ff7f0e", "#17becf"]
    plotted = 0

    for i, flow in enumerate(stats_el.findall("Flow")):
        hist = flow.find("delayHistogram")
        if hist is None:
            continue
        bins = sorted(hist.findall("bin"),
                      key=lambda b: float(b.get("start", "0")))
        xs, counts = [], []
        first_start = None
        for b in bins:
            start = float(b.get("start"))
            width = float(b.get("width"))
            count = int(b.get("count"))
            if first_start is None:
                first_start = start
            xs.append(start + width)
            counts.append(count)
        total = sum(counts)
        if total == 0:
            continue
        # Prepend (first_bin_start, 0) so the CDF visibly rises from 0.
        xs = [first_start] + xs
        cdf = [0.0]
        running = 0
        for c in counts:
            running += c
            cdf.append(running / total)

        fid = flow.get("flowId")
        info = classifier.get(fid, {})
        proto = proto_name.get(info.get("protocol", ""), "?")
        label = (f"Flow {fid} {proto} "
                 f"{info.get('sourceAddress','?')}→"
                 f"{info.get('destinationAddress','?')}")
        xs_ms = [x * 1000.0 for x in xs]
        ax.plot(xs_ms, cdf, label=label, color=colors[i % len(colors)],
                linewidth=1.5, drawstyle="steps-post")
        plotted += 1

    if plotted == 0:
        sys.exit("No delayHistogram found — was SerializeToXmlFile called "
                 "with enableHistograms=True?")

    ax.set_xlabel("End-to-end delay (ms)")
    ax.set_ylabel("CDF")
    ax.set_title("Per-flow delay CDF (FlowMonitor histogram)")
    ax.set_ylim(0, 1.02)
    ax.grid(True, alpha=0.3)
    ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    print(f"Delay CDF plot saved: {out_path}")


# ─────────────────────────────────────────────────────────────────────
# NS-3 → NS-2 ASCII trace converter  (best-effort, for tracegraph202)
# ─────────────────────────────────────────────────────────────────────
#
# NS-2 ASCII line format (what tracegraph expects):
#
#   event  time  from  to  type  size  flags  fid  src.sport  dst.dport  seq  pktid
#
# NS-3 ASCII line format (PointToPoint default):
#
#   <event> <time> <path> ns3::PppHeader (…) ns3::Ipv4Header (… length: N
#   PROTO A.B.C.D > E.F.G.H) ns3::TcpHeader (…) Payload (size=K)
#
# where <event> ∈ {+, -, r, d}. We extract: event, time, src-node from
# path (NodeList/<n>/…), packet size from Ipv4Header length, protocol,
# and src/dst addresses.  TCP sequence number and fid are left as 0.

NS3_LINE = re.compile(
    r"^(?P<event>[+\-rd])\s+(?P<time>[\d.]+)\s+"
    r"/NodeList/(?P<node>\d+)/"
)
IPV4_FIELDS = re.compile(
    r"ns3::Ipv4Header \([^)]*?length:\s*(?P<len>\d+)\s+"
    r"(?P<src>\d+\.\d+\.\d+\.\d+)\s*>\s*(?P<dst>\d+\.\d+\.\d+\.\d+)"
)
TCP_FIELDS = re.compile(
    r"ns3::TcpHeader \((?P<sport>\d+)\s*>\s*(?P<dport>\d+)[^)]*?"
    r"Seq=(?P<seq>\d+)"
)
UDP_FIELDS = re.compile(
    r"ns3::UdpHeader \((?P<sport>\d+)\s*>\s*(?P<dport>\d+)"
)


def convert_ns3_to_ns2(src_path, dst_path):
    pkt_id = 0
    written = 0
    with open(src_path) as fin, open(dst_path, "w") as fout:
        for line in fin:
            m = NS3_LINE.match(line)
            if not m:
                continue
            event = m.group("event")
            time = m.group("time")
            frm = m.group("node")

            ip = IPV4_FIELDS.search(line)
            if not ip:
                continue
            size = ip.group("len")
            src_ip, dst_ip = ip.group("src"), ip.group("dst")

            tcp = TCP_FIELDS.search(line)
            udp = UDP_FIELDS.search(line)
            if tcp:
                ptype, sport, dport, seq = (
                    "tcp", tcp.group("sport"), tcp.group("dport"),
                    tcp.group("seq"))
                fid = 1
            elif udp:
                ptype, sport, dport, seq = (
                    "cbr", udp.group("sport"), udp.group("dport"), 0)
                fid = 2
            else:
                ptype, sport, dport, seq, fid = "other", 0, 0, 0, 0

            # NS-2 used integer node ids on both sides; we only know one
            # endpoint from the trace path, so put "-1" on the other side
            # (tracegraph tolerates it for throughput plots).
            fout.write(f"{event} {time} {frm} -1 {ptype} {size} "
                       f"------- {fid} {src_ip}.{sport} {dst_ip}.{dport} "
                       f"{seq} {pkt_id}\n")
            pkt_id += 1
            written += 1
    print(f"Converted {written} lines → {dst_path}")
    if written == 0:
        print("WARN: no lines matched — did you pass an ns-3 ASCII .tr file?")


# ─────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    ap.add_argument("--flowmon", help="FlowMonitor XML to summarize")
    ap.add_argument("--plot", help="Save bar chart of per-flow throughput")
    ap.add_argument("--timeseries", metavar="TR_FILE",
                    help="NS-3 ASCII trace for per-flow throughput vs time")
    ap.add_argument("--timeseries-out", default="timeseries.png",
                    help="Output PNG for --timeseries (default: timeseries.png)")
    ap.add_argument("--timeseries-bin-ms", type=int, default=100,
                    help="Bin width in ms for --timeseries (default: 100)")
    ap.add_argument("--delay-cdf", metavar="FLOWMON_XML",
                    help="FlowMonitor XML to plot per-flow delay CDF")
    ap.add_argument("--delay-cdf-out", default="delay-cdf.png",
                    help="Output PNG for --delay-cdf (default: delay-cdf.png)")
    ap.add_argument("--convert", nargs=2, metavar=("SRC_TR", "DST_TR"),
                    help="Convert ns-3 ASCII trace to NS-2 format (legacy)")
    args = ap.parse_args()

    if not (args.flowmon or args.convert or args.timeseries or args.delay_cdf):
        ap.print_help()
        sys.exit(0)

    if args.flowmon:
        flows = parse_flowmon(args.flowmon)
        print_table(flows)
        if args.plot:
            plot_throughput(flows, args.plot)

    if args.timeseries:
        timeseries_plot(args.timeseries, args.timeseries_out,
                        bin_ms=args.timeseries_bin_ms)

    if args.delay_cdf:
        delay_cdf_plot(args.delay_cdf, args.delay_cdf_out)

    if args.convert:
        convert_ns3_to_ns2(*args.convert)


if __name__ == "__main__":
    main()
